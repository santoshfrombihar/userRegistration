using Microsoft.AspNetCore.Mvc;
using Registration.Models;
using System;
using System.Diagnostics;
using System.Text.Json;
using System.Xml;

namespace Registration.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly ILogger<HomeController> _logger;
        private const string JsonFilePath = "D:\\C# project\\Registration\\Data\\registrations.json";

        public HomeController(ILogger<HomeController> logger, IWebHostEnvironment hostingEnvironment)
        {
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SubmitRegistration(UserRegistraionModel model)
        {
            // Check if model is valid
            if (ModelState.IsValid)
            {
                // Assign hobbies from form data
                model.Hobbies = HttpContext.Request.Form["Hobbies"].ToArray();

                // Process photo if provided
               

                List<UserRegistraionModel> registration = LoadRegistration();

                // Add the new registration
                registration.Add(model);

                // Save registrations to the JSON file
                SaveRegistrations(registration);

               

                // Redirect to the ShowList action
                return RedirectToAction("ShowList");
            }
            else
            {
                // If model validation fails, return to the Index view with validation errors
                return View("Index", model);
            }
        }

        public IActionResult ShowList()
        {
            // Load registrations and pass them to the view
            IEnumerable<dynamic> registrations = LoadRegistrations();
            return View(registrations);
        }



        private void SaveRegistrations(List<UserRegistraionModel> registrations)
        {
            string json = JsonSerializer.Serialize(registrations, new JsonSerializerOptions { WriteIndented = true });
            System.IO.File.WriteAllText(JsonFilePath, json);
        }

        private List<UserRegistraionModel> LoadRegistration()
        {
            if (System.IO.File.Exists(JsonFilePath))
            {
                string json = System.IO.File.ReadAllText(JsonFilePath);
                var registrations = JsonSerializer.Deserialize<List<UserRegistraionModel>>(json);
                return registrations;
            }
            else
            {
                return new List<UserRegistraionModel>();
            }
        }

        private IEnumerable<dynamic> LoadRegistrations()
        {
            if (System.IO.File.Exists(JsonFilePath))
            {
                string json = System.IO.File.ReadAllText(JsonFilePath);
                var registrations = JsonSerializer.Deserialize<List<UserRegistraionModel>>(json);

                // Convert UserRegistraionModel objects to dynamic objects
                var dynamicList = registrations.Select(registration => new
                {
                    registration.Name,
                    registration.Email,
                    registration.Gender,
                    registration.State
                    // Add other properties as needed
                });

                return dynamicList;
            }
            else
            {
                return Enumerable.Empty<dynamic>();
            }
        }




    }
}

